using Microsoft.EntityFrameworkCore;
using GameStoreAPI.Data;  
using Microsoft.OpenApi.Models;
// Import the Data namespace

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));  // SQL Server
    // options.UseSqlite(builder.Configuration.GetConnectionString("DefaultConnection"));  // Uncomment for SQLite

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseAuthorization();
app.MapControllers();
app.Run();
