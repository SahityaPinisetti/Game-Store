namespace GameStoreAPI.Models
{
    public class Game
    {
        public required int Id { get; set; }           // Primary key
        public required string Title { get; set; }     // Name of the game
        public required string Description { get; set; } // A description of the game
        public required decimal Price { get; set; }    // Price of the game
        public required string Genre { get; set; }     // Genre (e.g., action, RPG, etc.)
        public required string Platform { get; set; }  // Platform (e.g., PC, Xbox, PS5, etc.)
    }
}
