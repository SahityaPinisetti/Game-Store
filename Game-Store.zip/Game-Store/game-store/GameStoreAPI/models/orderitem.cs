namespace GameStoreAPI.Models
{
    public class OrderItem
    {
        public int Id { get; set; }             // Primary key
        public int GameId { get; set; }         // Foreign key for the game purchased
        public required Game Game { get; set; }          // Navigation property to the Game object
        public int Quantity { get; set; }       // Number of copies of the game
        public decimal Price { get; set; }      // Price of the game at the time of the order
    }
}
