namespace GameStoreAPI.Models
{
    public class User
    {
        public int Id { get; set; }             // Primary key
        public required string Username { get; set; }    // User's username
        public required string Password { get; set; }    // User's password (should be hashed in real apps)
        public required string Role { get; set; }        // User's role (e.g., admin, customer)
    }
}
