using System;
using System.Collections.Generic;

namespace GameStoreAPI.Models
{
    public class Order
    {
        public int Id { get; set; }                  // Primary key
        public int UserId { get; set; }              // Foreign key for the user who placed the order
        public  required List<OrderItem> Items { get; set; }   // List of items in the order
        public DateTime OrderDate { get; set; }      // Date and time when the order was placed
        public decimal TotalAmount { get; set; }     // Total cost of the order
    }
}
