using Microsoft.EntityFrameworkCore; // Required to use EF Core
using GameStoreAPI.Models;           // Import your model classes

namespace GameStoreAPI.Data
{
    public class ApplicationDbContext : DbContext
    {
        // Constructor to pass configuration options
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        { }

        // DbSets represent the tables in your database
        public DbSet<Game> Games { get; set; }         // Represents the "Games" table
        public DbSet<User> Users { get; set; }         // Represents the "Users" table
        public DbSet<Order> Orders { get; set; }       // Represents the "Orders" table
        public DbSet<OrderItem> OrderItems { get; set; }// Represents the "OrderItems" table
    }
}
