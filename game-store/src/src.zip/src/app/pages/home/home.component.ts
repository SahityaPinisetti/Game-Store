import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CartService } from '../../services/cart.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-home',
  standalone: true,
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
  imports:[CommonModule]
})
export class HomeComponent {
  games = [
    { name: 'Game 1', price: 49.99, image: 'game-store/src/assets/justcause4.jpg', rating: 4.5 },
    { name: 'Game 2', price: 59.99, image: 'game-store/src/assets/justcause4.jpg', rating: 4.0 },
    { name: 'Game 1', price: 49.99, image: 'game-store/src/assets/justcause4.jpg', rating: 4.5 },
    { name: 'Game 2', price: 59.99, image: 'game-store/src/assets/justcause4.jpg', rating: 4.0 }
  
  ];
  constructor(private router: Router, private cartService: CartService) {}

  navigateToCart() {
    this.router.navigate(['/cart']);
  }

  addToCart(game: any) {
    console.log(`Added ${game.name} to cart!`);
  }
  
}
